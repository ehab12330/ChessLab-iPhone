# ChessLab iOS — engine & arrow update

This package upgrades the previous playable SwiftUI iOS project. Its features include a native alpha-beta search engine inspired by `engine.py`, automatic analysis and orange best-move arrow, automatically-played engine moves for the bottom side, 1/3/5/10 second thinking-time choices, legal move dots, undo, flip, and promotion.

**Not an exact engine port**: the original Python evaluator has additional heuristics, quiescence search, transposition table, repetition detection and PGN export that are not yet implemented. The original desktop project must remain preserved. This SwiftUI build has not been tested in Xcode or on an iPhone in this environment.

For updating an existing GitHub Actions build: replace `ChessLab-iOS-Fixed-Playable.zip` with this package's ZIP and update the `Extract fixed ChessLab` command in `.github/workflows/build-ios.yml` to `unzip -oq ChessLab-iOS-Original-Features.zip -d .`. Preserve the existing iOS build command including `ASSETCATALOG_COMPILER_APPICON_NAME=`. The included `.github/workflows` folder is older and should not override the current workflow.
