import SwiftUI

struct ContentView: View {
    @State private var game = ChessGame()
    @State private var flipped = false
    @State private var selected: Int? = nil
    @State private var targets: [ChessMove] = []
    @State private var hint: ChessMove? = nil
    @State private var score: Int = 0
    @State private var depth: Int = 0
    @State private var nodes: Int = 0
    @State private var busy = false
    @State private var thinkingSeconds: Int = 3
    @State private var version = 0
    private var bottomSide: ChessPiece.Side { flipped ? .black : .white }
    private let light = Color(red: 0.68, green: 0.75, blue: 0.82)
    private let dark = Color(red: 0.31, green: 0.42, blue: 0.55)

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                HStack {
                    VStack(alignment: .leading,spacing:3) {
                        Text("CHESS LAB").font(.system(size:30,weight:.heavy,design:.rounded))
                        Text("Original-style local analysis").font(.caption).foregroundStyle(.gray)
                    }
                    Spacer()
                    Text(busy ? "Thinking…" : "Ready")
                        .font(.caption).foregroundStyle(busy ? .orange : .green)
                }
                Text(game.status + (game.turn == bottomSide ? " • Engine (bottom)" : " • Your turn (top)"))
                    .font(.subheadline.bold())
                    .frame(maxWidth:.infinity,alignment:.leading)
                GeometryReader { geometry in
                    let side = geometry.size.width
                    ZStack(alignment:.topLeading) {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(),spacing:0),count:8),spacing:0) {
                            ForEach(0..<64,id:\.self) { shown in
                                let idx = flipped ? 63-shown : shown
                                let piece = game.squares[idx]
                                Button { tapped(idx) } label: {
                                    ZStack {
                                        Rectangle().fill(squareColor(shown,idx))
                                        if let piece {
                                            Image(piece.imageName).resizable().scaledToFit()
                                                .padding(side/110)
                                        }
                                        if targets.contains(where:{$0.to == idx}) {
                                            if piece == nil {
                                                Circle().fill(Color(red:0.12,green:0.31,blue:0.47).opacity(0.7))
                                                    .frame(width:side/36,height:side/36)
                                            } else {
                                                Rectangle().strokeBorder(Color(red:0.12,green:0.31,blue:0.47),lineWidth:3)
                                            }
                                        }
                                    }.frame(width:side/8,height:side/8)
                                }.buttonStyle(.plain)
                            }
                        }
                        if let hint {
                            ArrowShape(from: center(hint.from,side), to:center(hint.to,side))
                                .stroke(Color(red:0.98,green:0.40,blue:0.11),style:StrokeStyle(lineWidth:max(4,side/48),lineCap:.round,lineJoin:.round))
                                .allowsHitTesting(false)
                        }
                    }.frame(width:side,height:side)
                }
                .aspectRatio(1,contentMode:.fit)
                HStack(spacing:8) {
                    Button("New game") { game.reset(); selected=nil; targets=[]; refresh() }
                    Button("Undo") { game.undo(); selected=nil; targets=[]; refresh() }
                        .disabled(game.history.isEmpty)
                    Button("Flip board") { flipped.toggle(); selected=nil; targets=[]; refresh() }
                }.buttonStyle(.borderedProminent)
                HStack {
                    Text("Thinking time")
                    Picker("Thinking time",selection:$thinkingSeconds) {
                        ForEach([1,3,5,10],id:\.self) { n in Text("\(n)s").tag(n) }
                    }.pickerStyle(.segmented)
                }
                HStack {
                    Text("Score: \(String(format:"%.2f",Double(score)/100))")
                    Spacer()
                    Text("Depth: \(depth) • Nodes: \(nodes)")
                }.font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                if game.pendingPromotion != nil {
                    HStack {
                        Text("Promote:")
                        ForEach([ChessPiece.Kind.queen,.rook,.bishop,.knight],id:\.rawValue) { kind in
                            Button(kind.rawValue.capitalized) {
                                game.promote(to:kind); selected=nil; targets=[]; refresh()
                            }.buttonStyle(.bordered)
                        }
                    }
                }
                Text("Orange arrow: engine's best move • Blue dots: legal moves")
                    .font(.caption2).foregroundStyle(.gray)
            }.padding(14)
        }
        .background(Color(red:0.06,green:0.10,blue:0.16))
        .preferredColorScheme(.dark)
        .onAppear { refresh() }
        .onChange(of:thinkingSeconds) { _ in refresh() }
    }
    private func center(_ idx:Int,_ side:CGFloat) -> CGPoint {
        let shown=flipped ? 63-idx : idx
        return CGPoint(x:(CGFloat(shown%8)+0.5)*side/8,y:(CGFloat(shown/8)+0.5)*side/8)
    }
    private func squareColor(_ shown:Int,_ idx:Int) -> Color {
        if selected == idx { return Color(red:0.57,green:0.74,blue:0.9) }
        if game.lastMove?.from == idx || game.lastMove?.to == idx { return Color(red:0.44,green:0.59,blue:0.66) }
        return (shown/8+shown%8).isMultiple(of:2) ? light : dark
    }
    private func tapped(_ idx:Int) {
        guard !busy, game.turn != bottomSide, game.pendingPromotion == nil,
              !game.isCheckmate, !game.isStalemate else { return }
        if let source=selected, targets.contains(where:{$0.to == idx}) {
            _ = game.play(from:source,to:idx)
            selected=nil; targets=[]; refresh()
        } else if let piece=game.squares[idx], piece.side == game.turn {
            if selected == idx { selected=nil; targets=[] }
            else { selected=idx; targets=game.legalMoves(from:idx) }
        } else { selected=nil; targets=[] }
    }
    private func refresh() {
        version += 1
        let requestID=version
        let snapshot=game
        hint=nil; score=0; depth=0; nodes=0
        guard !snapshot.isCheckmate, !snapshot.isStalemate,
              snapshot.pendingPromotion == nil else { busy=false;return }
        busy=true
        let seconds=thinkingSeconds
        let engineTurn=snapshot.turn == bottomSide
        DispatchQueue.global(qos:.userInitiated).async {
            let result=ChessLabEngine().choose(snapshot,seconds:Double(seconds))
            DispatchQueue.main.async {
                guard version == requestID else {return}
                hint=result.move; score=result.score; depth=result.depth; nodes=result.nodes
                busy=false
                if engineTurn, let m=result.move {
                    _ = game.play(from:m.from,to:m.to)
                    if game.pendingPromotion != nil { game.promote(to:.queen) }
                    selected=nil; targets=[]
                    refresh()
                }
            }
        }
    }
}

struct ArrowShape: Shape {
    let from: CGPoint
    let to: CGPoint
    func path(in rect:CGRect) -> Path {
        var path=Path()
        let dx=to.x-from.x,dy=to.y-from.y
        let angle=atan2(dy,dx)
        let tip=CGPoint(x:to.x-cos(angle)*10,y:to.y-sin(angle)*10)
        let wing:CGFloat=14
        path.move(to:from)
        path.addLine(to:tip)
        for direction in [-1.0,1.0] {
            let a=angle+CGFloat(direction)*CGFloat.pi*0.79
            path.move(to:tip)
            path.addLine(to:CGPoint(x:tip.x+cos(a)*wing,y:tip.y+sin(a)*wing))
        }
        return path
    }
}
