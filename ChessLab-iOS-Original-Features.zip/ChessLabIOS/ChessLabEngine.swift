import Foundation

struct ChessAnalysis {
    let move: ChessMove?
    let score: Int
    let depth: Int
    let nodes: Int
}

// Native Swift adaptation of ChessLab's original Negamax / alpha-beta search.
// Original Python evaluator's exact attack, repetition and quiescence features
// are not all implemented here; this is not an identical engine-strength port.
final class ChessLabEngine {
    private let values: [ChessPiece.Kind:Int] = [
        .pawn:100, .knight:320, .bishop:335, .rook:500, .queen:900, .king:0
    ]
    private var nodes = 0
    private var deadline = Date.distantFuture
    private var stopped: () -> Bool = { false }
    private let mate = 100000

    func choose(_ board: ChessGame, seconds: Double, maxDepth: Int = 5, cancelled: @escaping () -> Bool = {false}) -> ChessAnalysis {
        stopped = cancelled
        deadline = Date().addingTimeInterval(max(0.15, seconds))
        nodes = 0
        let moves = board.searchMoves()
        guard !moves.isEmpty else { return ChessAnalysis(move:nil,score:0,depth:0,nodes:0) }
        var best = moves[0]
        var bestScore = evaluate(board)
        var completed = 0
        for depth in 1...maxDepth {
            if timedOut { break }
            var alpha = -mate * 2
            var chosen = best
            var completedIteration = true
            for move in ordered(board, moves, preferred: best) {
                if timedOut { completedIteration = false; break }
                let child = board.positionAfter(move)
                let value = -negamax(child, depth: depth-1, alpha: -mate*2, beta: -alpha, ply:1)
                if timedOut { completedIteration = false; break }
                if value > alpha { alpha = value; chosen = move }
            }
            if completedIteration { best = chosen; bestScore = alpha; completed = depth }
            else { break }
            if abs(bestScore) >= mate-1000 { break }
        }
        return ChessAnalysis(move:best,score:bestScore,depth:completed,nodes:nodes)
    }

    private var timedOut: Bool { Date() >= deadline || stopped() }
    private func scoreFor(_ piece: ChessPiece.Kind) -> Int { values[piece] ?? 0 }
    private func ordered(_ board: ChessGame, _ moves: [ChessMove], preferred: ChessMove? = nil) -> [ChessMove] {
        moves.sorted { a,b in
            func priority(_ m: ChessMove) -> Int {
                if m == preferred { return 1_000_000 }
                let victim = board.squares[m.to].map { scoreFor($0.kind) } ?? (m.enPassant ? 100 : 0)
                let attacker = board.squares[m.from].map { scoreFor($0.kind) } ?? 0
                return (victim > 0 ? 10_000 + victim*10-attacker : 0) + (m.promotion.map(scoreFor) ?? 0)*10
            }
            return priority(a) > priority(b)
        }
    }
    private func evaluate(_ board: ChessGame) -> Int {
        var score = 0
        let endgame = board.squares.compactMap { $0 }.count <= 12
        for (index, piece) in board.squares.enumerated() {
            guard let p = piece else { continue }
            let f = index % 8
            let r = p.side == .white ? 7-index/8 : index/8
            let center = 7.0 - Double(abs(2*f-7)+abs(2*r-7))/2.0
            var value = scoreFor(p.kind)
            switch p.kind {
            case .pawn: value += r*7 + Int(center*3)
            case .knight, .bishop: value += Int(center*10)
            case .rook: if r == 6 { value += 20 }
            case .queen: value += Int(center*3)
            case .king: value += endgame ? Int(center*12) : -Int(center*8)-r*12
            }
            score += (p.side == .white ? 1 : -1)*value
        }
        return board.turn == .white ? score : -score
    }
    private func negamax(_ board: ChessGame, depth: Int, alpha: Int, beta: Int, ply: Int) -> Int {
        nodes += 1
        if nodes % 64 == 0 && timedOut { return evaluate(board) }
        let legal = board.searchMoves()
        if legal.isEmpty { return board.isInCheck(board.turn) ? -mate + ply : 0 }
        if depth == 0 { return evaluate(board) }
        var a = alpha
        var best = -mate*2
        for m in ordered(board, legal) {
            if nodes % 64 == 0 && timedOut { break }
            let value = -negamax(board.positionAfter(m),depth:depth-1,alpha:-beta,beta:-a,ply:ply+1)
            best=max(best,value)
            a=max(a,value)
            if a>=beta { break }
        }
        return best == -mate*2 ? evaluate(board) : best
    }
}
