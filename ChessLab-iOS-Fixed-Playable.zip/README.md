# ChessLab iOS — updated playable chess prototype

This project replaces the original unicode glyph board with 12 consistent chess-piece image assets, and adds a Swift chess rules engine.

Features: legal chess movement, check and checkmate, stalemate, king-side and queen-side castling, en passant, choice of promotion, undo and board flipping.

This is **not** the original Python analysis engine or its full feature set; no computer opponent or engine evaluation is included.

## iOS cloud build
The `.github/workflows/build-ipa.yml` file is a GitHub Actions example. The existing repo may already have `.github/workflows/build-ios.yml` and can reuse it. Upload `ChessLabIOS` and `project.yml` with the directory paths preserved and run the workflow. On macOS the workflow uses XcodeGen to generate the project and Xcode to build an unsigned IPA. IPA must be signed for standard iOS installation.

## Local test of logic
On a host with Swift installed, compile ChessGame.swift with a standalone test script. Logic tests passed on Swift 6.2 Linux for initial legal moves, Fool's Mate, en passant, undo, and castling; iOS SwiftUI build has not been tested here.
