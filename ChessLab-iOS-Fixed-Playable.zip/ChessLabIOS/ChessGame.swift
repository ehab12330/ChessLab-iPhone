import Foundation

struct ChessPiece: Equatable {
    enum Side: String { case white, black; var opponent: Side { self == .white ? .black : .white } }
    enum Kind: String { case king, queen, rook, bishop, knight, pawn }
    var side: Side
    var kind: Kind
    var hasMoved = false
    var imageName: String { "\(side.rawValue)_\(kind.rawValue)" }
}

struct ChessMove: Equatable {
    let from: Int
    let to: Int
    var promotion: ChessPiece.Kind? = nil
    var enPassant = false
    var castle = false
}

struct ChessGame {
    private(set) var squares: [ChessPiece?] = Array(repeating: nil, count: 64)
    private(set) var turn: ChessPiece.Side = .white
    private(set) var enPassantTarget: Int? = nil
    private(set) var history: [ChessGame] = []
    private(set) var lastMove: ChessMove? = nil
    private(set) var pendingPromotion: ChessMove? = nil

    init() { reset() }
    private init(blank: Bool) { }
    mutating func reset() {
        squares = Array(repeating: nil, count: 64)
        let major: [ChessPiece.Kind] = [.rook,.knight,.bishop,.queen,.king,.bishop,.knight,.rook]
        for file in 0..<8 {
            squares[file] = ChessPiece(side: .black, kind: major[file])
            squares[8 + file] = ChessPiece(side: .black, kind: .pawn)
            squares[48 + file] = ChessPiece(side: .white, kind: .pawn)
            squares[56 + file] = ChessPiece(side: .white, kind: major[file])
        }
        turn = .white; history = []; lastMove = nil; enPassantTarget = nil; pendingPromotion = nil
    }
    func at(_ row: Int, _ col: Int) -> ChessPiece? {
        guard (0..<8).contains(row), (0..<8).contains(col) else { return nil }
        return squares[row * 8 + col]
    }
    private func valid(_ r: Int, _ c: Int) -> Bool { (0..<8).contains(r) && (0..<8).contains(c) }
    private func ray(_ from: Int, directions: [(Int, Int)]) -> [ChessMove] {
        let r = from / 8, c = from % 8
        guard let p = squares[from] else { return [] }
        var result: [ChessMove] = []
        for (dr,dc) in directions {
            var rr = r + dr, cc = c + dc
            while valid(rr,cc) {
                let dest = rr*8+cc
                if let other = squares[dest] {
                    if other.side != p.side && other.kind != .king { result.append(ChessMove(from: from, to: dest)) }
                    break
                }
                result.append(ChessMove(from: from, to: dest))
                rr += dr; cc += dc
            }
        }
        return result
    }
    private func candidates(_ pos: Int, attacksOnly: Bool = false) -> [ChessMove] {
        guard (0..<64).contains(pos), let p = squares[pos] else { return [] }
        let r = pos/8, c = pos%8
        let diagonals = [(-1,-1),(-1,1),(1,-1),(1,1)]
        let straights = [(-1,0),(1,0),(0,-1),(0,1)]
        switch p.kind {
        case .rook: return ray(pos, directions: straights)
        case .bishop: return ray(pos, directions: diagonals)
        case .queen: return ray(pos, directions: straights+diagonals)
        case .knight:
            return [(-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)].compactMap { dr,dc in
                let rr=r+dr, cc=c+dc
                guard valid(rr,cc) else { return nil }
                let target=rr*8+cc
                guard squares[target]?.side != p.side, squares[target]?.kind != .king else { return nil }
                return ChessMove(from: pos, to: target)
            }
        case .pawn:
            let direction = p.side == .white ? -1 : 1
            var moves: [ChessMove] = []
            for dc in [-1,1] {
                let rr=r+direction, cc=c+dc
                guard valid(rr,cc) else { continue }
                let target=rr*8+cc
                if attacksOnly { moves.append(ChessMove(from:pos,to:target)); continue }
                if let targetPiece=squares[target], targetPiece.side != p.side && targetPiece.kind != .king {
                    moves.append(ChessMove(from:pos,to:target))
                } else if target == enPassantTarget,
                          let victim=squares[r*8+cc], victim.kind == .pawn && victim.side != p.side {
                    moves.append(ChessMove(from:pos,to:target,enPassant:true))
                }
            }
            if !attacksOnly {
                let nr=r+direction
                if valid(nr,c) && squares[nr*8+c] == nil {
                    moves.append(ChessMove(from:pos,to:nr*8+c))
                    let home = p.side == .white ? 6 : 1
                    let two=r+2*direction
                    if r == home && squares[two*8+c] == nil { moves.append(ChessMove(from:pos,to:two*8+c)) }
                }
            }
            return moves
        case .king:
            var moves: [ChessMove] = []
            for (dr,dc) in straights+diagonals {
                let rr=r+dr, cc=c+dc
                guard valid(rr,cc) else { continue }
                let dest=rr*8+cc
                if squares[dest]?.side != p.side && squares[dest]?.kind != .king {
                    moves.append(ChessMove(from:pos,to:dest))
                }
            }
            if !attacksOnly && !p.hasMoved && !isInCheck(p.side) {
                for rookFile in [0,7] {
                    let rookPos=r*8+rookFile
                    guard let rook=squares[rookPos], rook.side == p.side, rook.kind == .rook, !rook.hasMoved else { continue }
                    let kingTargetFile = rookFile == 0 ? c-2 : c+2
                    guard valid(r,kingTargetFile) else { continue }
                    let intervening = rookFile == 0 ? Array((rookFile+1)..<c) : Array((c+1)..<rookFile)
                    guard intervening.allSatisfy({ squares[r*8+$0] == nil }) else { continue }
                    let passFile = rookFile == 0 ? c-1 : c+1
                    guard !isAttacked(r*8+passFile, by:p.side.opponent), !isAttacked(r*8+kingTargetFile, by:p.side.opponent) else { continue }
                    moves.append(ChessMove(from:pos,to:r*8+kingTargetFile,castle:true))
                }
            }
            return moves
        }
    }
    func isAttacked(_ position: Int, by attacker: ChessPiece.Side) -> Bool {
        let tr = position / 8, tc = position % 8
        for origin in 0..<64 {
            guard let piece = squares[origin], piece.side == attacker else { continue }
            let r = origin / 8, c = origin % 8
            let dr = tr-r, dc = tc-c
            switch piece.kind {
            case .pawn:
                if dr == (attacker == .white ? -1 : 1) && abs(dc) == 1 { return true }
            case .knight:
                if (abs(dr) == 2 && abs(dc) == 1) || (abs(dr) == 1 && abs(dc) == 2) { return true }
            case .king:
                if max(abs(dr), abs(dc)) == 1 { return true }
            case .bishop, .rook, .queen:
                let diagonal = abs(dr) == abs(dc) && dr != 0
                let straight = (dr == 0 && dc != 0) || (dc == 0 && dr != 0)
                guard (diagonal && piece.kind != .rook) || (straight && piece.kind != .bishop) else { continue }
                let stepR = dr == 0 ? 0 : (dr > 0 ? 1 : -1)
                let stepC = dc == 0 ? 0 : (dc > 0 ? 1 : -1)
                var rr=r+stepR, cc=c+stepC
                var clear=true
                while rr != tr || cc != tc {
                    if squares[rr*8+cc] != nil { clear=false; break }
                    rr += stepR; cc += stepC
                }
                if clear { return true }
            }
        }
        return false
    }
    func isInCheck(_ side: ChessPiece.Side) -> Bool {
        guard let position=squares.firstIndex(where: { $0?.side == side && $0?.kind == .king }) else { return true }
        return isAttacked(position, by:side.opponent)
    }
    func legalMoves(from: Int) -> [ChessMove] {
        guard (0..<64).contains(from), squares[from]?.side == turn, pendingPromotion == nil else { return [] }
        return candidates(from).filter { move in
            var trial=self
            trial.applyUnchecked(move)
            return !trial.isInCheck(turn)
        }
    }
    func allLegalMoves() -> [ChessMove] {
        (0..<64).flatMap { legalMoves(from:$0) }
    }
    var isCheckmate: Bool { isInCheck(turn) && allLegalMoves().isEmpty }
    var isStalemate: Bool { !isInCheck(turn) && allLegalMoves().isEmpty }
    var status: String {
        if isCheckmate { return "Checkmate — \(turn == .white ? "Black" : "White") wins" }
        if isStalemate { return "Stalemate — draw" }
        return "\(turn == .white ? "White" : "Black") to move\(isInCheck(turn) ? " — Check!" : "")"
    }
    private mutating func applyUnchecked(_ move: ChessMove) {
        guard var piece=squares[move.from] else { return }
        squares[move.from]=nil
        if move.enPassant { squares[(move.from/8)*8 + move.to%8] = nil }
        if move.castle {
            let row=move.from/8
            let kingSide=move.to%8 > move.from%8
            let rookFrom=row*8+(kingSide ? 7 : 0)
            let rookTo=row*8+(kingSide ? 5 : 3)
            if var rook=squares[rookFrom] {
                rook.hasMoved=true
                squares[rookFrom]=nil
                squares[rookTo]=rook
            }
        }
        enPassantTarget = nil
        if piece.kind == .pawn && abs(move.to/8 - move.from/8) == 2 { enPassantTarget = (move.to + move.from)/2 }
        if let promotion=move.promotion { piece.kind=promotion }
        piece.hasMoved=true
        squares[move.to]=piece
        lastMove=move
        turn=turn.opponent
    }
    @discardableResult mutating func play(from: Int, to: Int) -> Bool {
        guard let move=legalMoves(from:from).first(where:{$0.to == to}) else { return false }
        if squares[from]?.kind == .pawn && (to/8 == 0 || to/8 == 7) {
            pendingPromotion=move; return true
        }
        var previous=self; previous.history=[]
        history.append(previous)
        applyUnchecked(move)
        return true
    }
    mutating func promote(to kind: ChessPiece.Kind) {
        guard var move=pendingPromotion, [.queen,.rook,.bishop,.knight].contains(kind) else { return }
        var previous=self; previous.pendingPromotion=nil; previous.history=[]
        history.append(previous)
        pendingPromotion=nil
        move.promotion=kind
        applyUnchecked(move)
    }
    mutating func undo() {
        guard let previous=history.popLast() else { return }
        let older=history
        self=previous
        history=older
    }
}
