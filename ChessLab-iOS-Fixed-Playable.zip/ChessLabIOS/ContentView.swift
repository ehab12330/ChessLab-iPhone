import SwiftUI

struct ContentView: View {
    @State private var game = ChessGame()
    @State private var flipped = false
    @State private var selection: Int? = nil
    @State private var suggested: [ChessMove] = []
    private let light = Color(red: 0.89, green: 0.91, blue: 0.94)
    private let dark = Color(red: 0.31, green: 0.43, blue: 0.58)

    var body: some View {
        VStack(spacing: 15) {
            Text("ChessLab")
                .font(.system(size: 34, weight: .bold, design: .rounded))
                .foregroundStyle(.primary)
            Text(game.status)
                .font(.headline)
                .foregroundStyle(game.isInCheck(game.turn) ? .red : .secondary)
                .accessibilityIdentifier("gameStatus")
            GeometryReader { geometry in
                let size = min(geometry.size.width, geometry.size.height)
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 0), count: 8), spacing: 0) {
                    ForEach(0..<64, id: \.self) { shown in
                        let position = flipped ? 63-shown : shown
                        let piece = game.squares[position]
                        let isTarget = suggested.contains { $0.to == position }
                        Button { tapped(position) } label: {
                            ZStack {
                                Rectangle()
                                    .fill(squareColor(shown, position: position))
                                if let piece {
                                    Image(piece.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .padding(size / 105)
                                }
                                if isTarget {
                                    Circle()
                                        .fill(Color.yellow.opacity(piece == nil ? 0.55 : 0.01))
                                        .frame(width: size/24, height: size/24)
                                    if piece != nil {
                                        Rectangle().strokeBorder(.yellow, lineWidth: 4)
                                    }
                                }
                            }
                            .frame(width: size/8, height: size/8)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(squareName(position))
                    }
                }
                .frame(width:size, height:size)
                .frame(maxWidth:.infinity, maxHeight:.infinity)
            }
            .aspectRatio(1, contentMode: .fit)
            HStack(spacing: 12) {
                Button("New game") {
                    game.reset(); selection=nil; suggested=[]
                }
                Button("Undo") {
                    game.undo(); selection=nil; suggested=[]
                }
                .disabled(game.history.isEmpty)
                Button("Flip board") {
                    flipped.toggle(); selection=nil; suggested=[]
                }
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.regular)
            if game.pendingPromotion != nil {
                VStack(spacing: 10) {
                    Text("Promote pawn to:").font(.headline)
                    HStack {
                        ForEach([ChessPiece.Kind.queen, .rook, .bishop, .knight], id:\.rawValue) { kind in
                            Button(kind.rawValue.capitalized) {
                                game.promote(to:kind)
                                selection=nil; suggested=[]
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                }
            }
            Text("Legal moves • checkmate • castling • en passant • promotion")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 18)
        .background(Color(red:0.07, green:0.09, blue:0.12))
        .preferredColorScheme(.dark)
    }
    private func squareColor(_ shown: Int, position: Int) -> Color {
        if selection == position { return Color(red:0.83,green:0.56,blue:0.2) }
        if game.lastMove?.from == position || game.lastMove?.to == position {
            return Color(red:0.67,green:0.73,blue:0.40)
        }
        return ((shown/8 + shown%8)%2 == 0) ? light : dark
    }
    private func squareName(_ i: Int) -> String {
        let file = String(UnicodeScalar(97 + i%8)!)
        return "\(file)\(8-i/8)"
    }
    private func tapped(_ index: Int) {
        guard game.pendingPromotion == nil, !game.isCheckmate, !game.isStalemate else { return }
        if let selected = selection, suggested.contains(where:{$0.to == index}) {
            _ = game.play(from:selected,to:index)
            selection=nil; suggested=[]
            return
        }
        if game.squares[index]?.side == game.turn {
            if selection == index { selection=nil; suggested=[] }
            else { selection=index; suggested=game.legalMoves(from:index) }
        } else {
            selection=nil; suggested=[]
        }
    }
}
